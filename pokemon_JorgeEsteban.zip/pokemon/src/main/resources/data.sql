INSERT INTO Entrenador (nombre, active) VALUES ('Ash', 1);
INSERT INTO Entrenador (nombre, active) VALUES ('Misty', 1);
INSERT INTO Entrenador (nombre, active) VALUES ('Brock', 1);

INSERT INTO Region(nombre) VALUES ( 'Kanto');
INSERT INTO Region(nombre) VALUES ('Murcia');
INSERT INTO Region(nombre) VALUES ('Valladolid');
INSERT INTO Region(nombre) VALUES ('Zaragoza');


INSERT INTO Region (nombre) VALUES ('Kanto');
INSERT INTO Region (nombre) VALUES ('Johto');
INSERT INTO Region (nombre) VALUES ('Hoenn');
INSERT INTO Pokemon (nombre, region) VALUES ('Bulbasaur', 1);
INSERT INTO Pokemon (nombre, region) VALUES ('Ivysaur', 1);
INSERT INTO Pokemon (nombre, region) VALUES ('Venusaur', 1);
INSERT INTO Pokemon (nombre, region) VALUES ('Charmander', 2);
INSERT INTO Pokemon (nombre, region) VALUES ('Charmeleon', 2);
INSERT INTO Pokemon (nombre, region) VALUES ('Charizard', 2);
INSERT INTO Pokemon (nombre, region) VALUES ('Squirtle', 3);
INSERT INTO Pokemon (nombre, region) VALUES ('Wartortle', 3);
INSERT INTO Pokemon (nombre, region) VALUES ('Blastoise', 3);